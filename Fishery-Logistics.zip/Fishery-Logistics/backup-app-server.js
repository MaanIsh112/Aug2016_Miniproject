var express = require('express');
var mysql = require('mysql');
var _ = require('underscore');

var questions = require('./app-questions'); // Question list
var flds = require('./fld-data');

var app = express();

var connections = [];
var title = 'Fishery Logistics';
var audience = []; // Many audience
var speaker = {}; // One 
var currentQuestion = false;
var results = {
    a: 0,
    b: 0,
    c: 0,
    d: 0
}

// From where express should access our files
app.use(express.static('./public'));
app.use(express.static('./node_modules/bootstrap/dist'));

var server = app.listen(process.env.PORT || 3000);
// Creating a socket server which is also listeing to localhost:<port>
var io = require('socket.io').listen(server);

flds = [{
    "fld_id": "100006",
    "fld_number": "none of my true potential",
    "landed_date": "some of my true potential",
    "vessel_name": "most of my true potential",
    "port_name": "all of my true potential",
    "transport_company_name": "none of my true potential",
    "driver_name": "some of my true potential",
    "truck_number": "most of my true potential",
    "status_name": "all of my true potential"

}, {
    "fld_id": "100007",
    "fld_number": "none of my true potential",
    "landed_date": "some of my true potential",
    "vessel_name": "most of my true potential",
    "port_name": "all of my true potential",
    "transport_company_name": "none of my true potential",
    "driver_name": "some of my true potential",
    "truck_number": "most of my true potential",
    "status_name": "all of my true potential"
}, {
    "fld_id": "100008",
    "fld_number": "none of my true potential",
    "landed_date": "some of my true potential",
    "vessel_name": "most of my true potential",
    "port_name": "all of my true potential",
    "transport_company_name": "none of my true potential",
    "driver_name": "some of my true potential",
    "truck_number": "most of my true potential",
    "status_name": "all of my true potential"
}, {
    "fld_id": "100009",
    "fld_number": "none of my true potential",
    "landed_date": "some of my true potential",
    "vessel_name": "most of my true potential",
    "port_name": "all of my true potential",
    "transport_company_name": "none of my true potential",
    "driver_name": "some of my true potential",
    "truck_number": "most of my true potential",
    "status_name": "all of my true potential"
}, {
    "fld_id": "100010",
    "fld_number": "none of my true potential",
    "landed_date": "some of my true potential",
    "vessel_name": "most of my true potential",
    "port_name": "all of my true potential",
    "transport_company_name": "none of my true potential",
    "driver_name": "some of my true potential",
    "truck_number": "most of my true potential",
    "status_name": "all of my true potential"
}];

var connection = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: '',
    database: 'fish_landing'
});

app.use('/', function(req, res, next) {
    //console.log('Request Url:' + req.url);
    var lfr_id = 100002;
    var sql = 'SELECT F.fld_id, F.fld_number, F.landed_date, F.vessel_name, F.port_name, F.transport_company_name, F.driver_name, truck_number, FS.status_name ' +
        'FROM fld F, fld_status FS, lfr L ' +
        'WHERE F.status_id = FS.status_id ' +
        'AND F.lfr_id = L.lfr_id ' +
        'AND FS.status_id = 3 ' +
        'AND L.lfr_id = ' + lfr_id;

    connection.query(sql,
        function(error, result) {
            if (error) {
                console.log(error);
            }

            if (result.length !== 0) {
                for (var row = 0; row < result.length; row++) {
                    console.log(result[row].fld_id);
                    console.log(result[row].fld_number);
                    console.log(result[row].landed_date);
                    console.log(result[row].port_name);
                    console.log(result[row].vessel_name);
                    console.log(result[row].transport_company_name);
                    console.log(result[row].driver_name);
                    console.log(result[row].truck_number);
                    console.log(result[row].status_name);
                    console.log('----------------------');
                }
                console.log(`(${result.length} Records Found)`);
            } else {
                console.log('No Records Found')
            }
        }
    );
    connection.end();

    next();
});







io.sockets.on('connection', function(socket) {

    socket.once('disconnect', function() {
        // _.findWhere takes an array to search and returns the item in the array based on the searching parameter
        // this.id => disconnected socket id
        var member = _.findWhere(audience, { id: this.id });
        // If the member is found
        if (member) {
            audience.splice(audience.indexOf(member), 1);
            // Emitting an event to all the sockets
            io.sockets.emit('audience', audience);
            console.log(`Left: ${member.name} (${audience.length} members)`);
        }
        // If the disconnected socket is the speaker socket
        else if (this.id === speaker.id) {
            console.log(`${speaker.name} has left. ${title} is over.`);
            speaker = {};
            title = 'Untitled Presentation';
            io.sockets.emit('end', { title: title, speaker: '' });
        }

        connections.splice(connections.indexOf(socket), 1);
        socket.disconnect();
        console.log(`Disconnected: ${connections.length} are remaining`);
    });

    // join event 
    // When a join event occures on the server, joined event is emitted
    // back to the client and passes that data to the client.
    // All incoming and outgoing data goes to the app component.
    // componentWillMount() of app will listen to this.
    socket.on('join', function(payload) {
        var newMember = {
            // this => socket
            id: this.id,
            name: payload.name,
            type: 'audience'
        };
        // joined event |||| this => socket
        this.emit('joined', newMember);
        // Add new member to the audience[] 
        audience.push(newMember);
        // io.socket => every socket
        io.sockets.emit('audience', audience);
        console.log(`Audience Joined ${payload.name}`);
    });

    socket.on('start', function(payload) {
        speaker.name = payload.name;
        speaker.id = this.id;
        speaker.type = 'speaker';
        title = payload.title;
        // Emitting the same 'joined' event which was used for members
        this.emit('joined', speaker);
        io.sockets.emit('start', { title: title, speaker: speaker.name });
        console.log(`Presentation started: ${title} by ${speaker.name}`);
    });

    socket.on('ask', function(question) {
        currentQuestion = question;
        // when asking a new question, make the result object empty
        results = { a: 0, b: 0, c: 0, d: 0 };

        io.sockets.emit('ask', currentQuestion);
        console.log(`Question Asked: ${question.q}`);
    });

    socket.on('answer', function(payload) {
        results[payload.choice]++;
        io.sockets.emit('results', results);
        console.log('Answer: %s - %j', payload.choice, results);
    });

    // socket.emit => emit events that ca// One speakern be handled by the client
    socket.emit('welcome', {
        title: title,
        audience: audience,
        speaker: speaker.name,
        questions: questions,
        currentQuestion: currentQuestion,
        results: results,
        flds: flds
    });

    connections.push(socket);
    console.log(`Connected: ${connections.length} are remaining`);
});

console.log(`Polling server is running at port ${server.address().port}`);