import React, { Component } from 'react';
import Router from 'react-router';
import io from 'socket.io-client';

import Header from './parts/Header'
var { RouteHandler } = Router;

class App extends Component {
    constructor() {
        super();

        this.state = {
            status: 'disconnected',
            title: '',
            member: {},
            audience: [],
            speaker: '',
            questions: [],
            currentQuestion: false,
            results: {},
            fldData: []
        };
    }

    // All incoming data from the server will be added to the listners inside componentWillMount
    componentWillMount() {
        this.socket = io('http://localhost:3000');

        // Connect => New members joining |||| Browser refreshing
        this.socket.on('connect', () => {
            var member = (sessionStorage.member) ? JSON.parse(sessionStorage.member) : null;

            if (member && member.type === 'audience') {
                this.emit('join', member);
            }
            else if (member && member.type === 'speaker') {
                this.emit('start', { name: member.name, title: sessionStorage.title });
            }

            this.setState({ status: 'connected' });
        });

        // Disconnect => Close the browser
        this.socket.on('disconnect', () => {
            this.setState({
                status: 'disconnected',
                title: 'disconnected',
                speaker: ''
            });
        });

        // First time loading the page
        this.socket.on('welcome', (serverState) => {
            this.setState(serverState)
        });

        // This event will fire once we recieved an audience member
        this.socket.on('joined', (member) => {
            sessionStorage.member = JSON.stringify(member);
            this.setState({ member: member });
        });

        this.socket.on('audience', (newAudience) => {
            this.setState({ audience: newAudience });
        });

        this.socket.on('flds', (newFlds) => {
            this.setState({ flds: newFlds });
        });

        // Speaker starts the presentation
        this.socket.on('start', (presentation) => {
            if (this.state.member.type === 'speaker') {
                sessionStorage.title = presentation.title;
            }
            this.setState(presentation);
        });

        // End of the presentation
        this.socket.on('end', (serverState) => {
            this.setState(serverState)
        });

        // Speaker asks a question
        this.socket.on('ask', (question) => {
            sessionStorage.answer = '';
            this.setState({
                currentQuestion: question,
                results: { a: 0, b: 0, c: 0, d: 0 }
            });
        });

        // Polling results
        this.socket.on('results', (data) => {
            this.setState({ results: data });
        });
    }

    // All out going data to the server will go through emit()
    emit(eventName, payload) {
        // this.socket has its own emit(). It is used to send data to server.
        this.socket.emit(eventName, payload);
    }

    render() {
        return (
            <div>
                <Header {...this.state} />
                <RouteHandler emit={this.emit.bind(this)} {...this.state} />
            </div>
        );
    }

}

module.exports = App;