import React, { Component } from 'react';
import Router from 'react-router';
var Link = Router.Link;

class NotFound extends Component {
    render() {
        return (
            <div id='not-found'>
                <h1>Error 404</h1>
                <p>
                    The requested page cannot be found.
                    Were you looking for one of these:
                </p>

                <Link to='/'>Join as Audience</Link>
                <Link to='/speaker'>Start the presentation</Link>
                <Link to='/board'>View the board</Link>
            </div>
        );
    }
}

module.exports = NotFound;