import React, { Component } from 'react';
// Display is used to display speaker's' join form when we dont have a member,
// or speaker's home page when we have a member.
import Display from './parts/display';
import JoinSpeaker from './parts/join-speaker';
import Attendance from './parts/attendance';
import Questions from './parts/questions';
import FLDS from './parts/flds';

class FldList extends Component {
	render() {
		return (
			<div>
				<FLDS flds={this.props.flds} />
			</div>
		);
	}
}

module.exports = FldList;