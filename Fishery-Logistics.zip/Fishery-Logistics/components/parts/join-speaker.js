import React, { Component } from 'react';

class JoinSpeaker extends Component {
    render() {
        return (
            <form action='javascript:void(0)' onSubmit={this.startPresentation.bind(this)}>
                <label>Full Name</label>
                <input ref='name'
                    className='form-control'
                    placeholder='Enter your full name'
                    required />

                <label>Presentation Title</label>
                <input ref='title'
                    className='form-control'
                    placeholder='Enter the title for the presentation'
                    required />

                <button className='btn btn-primary'>Join</button>
            </form>
        );
    }

    startPresentation() {
        var speakerName = React.findDOMNode(this.refs.name).value;
        var title = React.findDOMNode(this.refs.title).value;
        this.props.emit('start', {name: speakerName, title: title});
    }
}

module.exports = JoinSpeaker;
