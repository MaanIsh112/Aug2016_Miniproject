import React, { Component } from 'react';
var Link = require('react-router').Link;

class JoinAudiance extends Component {
    render() {
        return (
            <form action='javascript:void(0)' onSubmit={this.joinAudianec.bind(this)}>
                <label>Full Name</label>
                <input ref='name'
                    className='form-control'
                    placeholder='Enter your full name'
                    required />
                <button className='btn btn-primary'>Join</button>
                <Link to='/speaker'>Join as the speaker</Link>
                <Link to='/board'>Go to the board</Link>
                <Link to='/fld-list'>Go to FLD list</Link>
            </form>
        );
    }

    joinAudianec() {
        var memberName = React.findDOMNode(this.refs.name).value;
        // This join event is declared in server.js
        // payload is member name.
        this.props.emit('join', { name: memberName });
    }
}

module.exports = JoinAudiance;
