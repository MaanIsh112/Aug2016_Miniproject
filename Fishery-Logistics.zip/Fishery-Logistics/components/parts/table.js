import React, { Component } from 'react';

class FLDS extends Component {
    render() {
        return (
            <div>
                <table className='table table-hover'>
                    <thead class="default-back">
                        <tr>
                            <th>FLD ID</th>
                            <th>FLD Number</th>
                            <th>Landed Date</th>
                            <th>Port Name</th>
                            <th>Vessel Name</th>
                            <th>Transport Company</th>
                            <th>Driver Name</th>
                            <th>Truck Number</th>
                            <th>FLD Status</th>
                        </tr>
                    </thead>
                        { this.props.flds.map(this.addFldRow) }
                    <tbody>

                    </tbody>
                </table>
            </div>
        );
    }

    addFldRow(fld, index) {
        return (
            <tr key={index}>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
            </tr>
        );
    }
}

module.exports = FLDS;