var React = require('react');

var Questions = React.createClass({
    render() {
        return (
           <div id='questions' className='row'>
            <h2>Questions</h2>
                {this.props.questions.map(this.addQuestion)}
           </div>
        );
    },

     addQuestion(question, index) {
        return (
            <div key={index} className='col-xs-12 col-sm-6 col-md-3'>
                <span onClick={this.ask.bind(null, question)}>{question.q}</span>
            </div>
        );
    },

    ask(question) {
        this.props.emit('ask', question);
    }
});

module.exports = Questions;