module.exports = {
    // Root client js file
    entry: "./app-client.js",
    // Where to put the processed file
    output: {
        filename: "public/bundle.js"
    },
    module: {
        loaders: [{
            // When the webpack is run, babel will not run on these files
            exclude: /(node_modules|app-server.js)/,
            // Loader name
            loader: 'babel'
        }]
    }
}