import React from 'react'
import Router from 'react-router'

import App from './components/app';
import Audience from './components/audience';
import Speaker from './components/speaker';
import Board from './components/board';
import FldList from './components/fld-list';
import NotFound from './components/not-found';

var { Route, DefaultRoute, NotFoundRoute } = Router;

var routes = (
	<Route handler={App}>
		<DefaultRoute handler={Audience} />
		<Route name="speaker" path="speaker" handler={Speaker}></Route>
		<Route name="board" path="board" handler={Board}></Route>
		<Route name="fldList" path="fld-list" handler={FldList}></Route>
		<NotFoundRoute handler={NotFound} />
	</Route>
);

Router.run(routes, function(Handler) {
	React.render(<Handler />, document.getElementById('react-container'));
});