module.exports = [
    {
        "q": "How much of your true potential are you using?",
        "a": "none of my true potential",
        "b": "some of my true potential",
        "c": "most of my true potential",
        "d": "all of my true potential"
    },
    {
        "q": "How much money would you like to make?",
        "a": "no money",
        "b": "some money",
        "c": "most of the money",
        "d": "all of the money"
    },
    {
        "q": "How much money would you like to put down?",
        "a": "more money than I have",
        "b": "all of my money",
        "c": "some of my money",
        "d": "no money at all"
    },
    {
        "q": "Who do you want to be your boss?",
        "a": "someone bossy",
        "b": "someone who knows what they are doing",
        "c": "I'm my own boss",
        "d": "no boss at all"
    }
];